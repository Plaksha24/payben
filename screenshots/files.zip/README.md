# 💳 Payben — Digital Wallet & Recharge System

🔗 **Repo:** [github.com/Plaksha24/payben](https://github.com/Plaksha24/payben)

A full-stack digital wallet application that lets users register, authenticate, top up their wallet through a real payment gateway (Razorpay), and track transaction history — built to demonstrate secure, end-to-end transactional system design.

---

## 🎯 Problem Statement

Prepaid recharge and wallet top-up flows in consumer apps (Paytm, PhonePe, etc.) are closed-source, monolithic systems. Payben implements a scaled-down but functionally complete version of the same core mechanism: **secure user authentication + wallet balance management + real payment gateway integration with server-side verification.**

---

## ✨ Features

- 🔐 User registration & login with hashed passwords (bcrypt)
- 🪪 JWT-based session authentication
- 💰 Digital wallet with live balance tracking
- 💳 Real payment gateway integration (Razorpay, test mode)
- ✅ Server-side payment signature verification (prevents fake/spoofed payments)
- 📜 Transaction history log
- 🎨 Responsive Bootstrap frontend

---

## 📸 Screenshots

| Login | Dashboard & Transactions | Razorpay Checkout |
|---|---|---|
| ![Login](screenshots/login.png) | ![Dashboard](screenshots/dashboard.png) | ![Checkout](screenshots/checkout.png) |

---

## 🛠️ Tech Stack

| Layer | Technology |
|---|---|
| Frontend | HTML, CSS, Bootstrap 5, Vanilla JS |
| Backend | Python, FastAPI |
| Database | MySQL (via SQLAlchemy ORM) |
| Auth | JWT (python-jose), bcrypt |
| Payments | Razorpay API (test mode) |
| Server | Uvicorn |

---

## 🏗️ Architecture

```
Frontend (HTML/JS/Bootstrap)
        │
        ▼  fetch() calls
FastAPI Backend (main.py)
        │
        ├── auth.py       → password hashing (bcrypt) + JWT tokens
        ├── models.py      → SQLAlchemy ORM models
        ├── database.py    → MySQL connection/session
        └── Razorpay SDK   → order creation + payment verification
        │
        ▼
MySQL Database (users, wallets, transactions)
```

---

## 📂 Database Schema

- **users** — id, name, email, password_hash, created_at
- **wallets** — id, user_id (FK), balance
- **transactions** — id, user_id (FK), razorpay_order_id, razorpay_payment_id, amount, status, created_at

---

## 🔒 Security Highlights

- Passwords are never stored in plain text — hashed using `bcrypt`.
- Payment confirmation is **never trusted from the client**. After Razorpay redirects with a payment response, the backend independently recomputes the HMAC-SHA256 signature using the secret key (server-side only) and compares it — only then is the wallet balance updated.
- JWTs are used for session auth instead of resending credentials on every request.
- Secrets (Razorpay keys) are loaded from a `.env` file, never hardcoded or committed to version control.

---

## 🚀 How It Works

1. User registers → account + wallet (₹0 balance) created in MySQL
2. User logs in → receives a signed JWT token
3. Dashboard fetches live wallet balance from the backend
4. User initiates a recharge → backend creates a Razorpay order
5. Razorpay checkout opens → user completes test payment
6. Backend verifies the payment signature server-side
7. On success, wallet balance is updated and a transaction record is logged
8. Transaction history is displayed on the dashboard

---

## ⚙️ Setup & Installation

### Prerequisites
- Python 3.12+
- MySQL (via XAMPP or standalone)
- Razorpay test account (free)

### Backend Setup

```bash
# Clone the repo
git clone https://github.com/Plaksha24/payben.git
cd payben

# Create virtual environment
python -m venv venv
venv\Scripts\activate      # Windows
source venv/bin/activate   # macOS/Linux

# Install dependencies
pip install fastapi uvicorn sqlalchemy pymysql python-jose bcrypt razorpay python-multipart python-dotenv

# Set up the database
# Run the SQL schema in phpMyAdmin or MySQL CLI (see schema below)

# Create a .env file in the project root:
# RAZORPAY_KEY_ID=your_key_id
# RAZORPAY_KEY_SECRET=your_key_secret

# Run the server
uvicorn main:app --reload
```

Backend runs at `http://localhost:8000` — API docs available at `http://localhost:8000/docs`.

### Frontend Setup

Open `index.html` with **VS Code Live Server** (or any static file server). Update the Razorpay `key` in `dashboard.html` with your Key ID.

### Database Schema (MySQL)

```sql
CREATE DATABASE payben;
USE payben;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE wallets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    balance DECIMAL(10,2) DEFAULT 0.00,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    razorpay_order_id VARCHAR(100),
    razorpay_payment_id VARCHAR(100),
    amount DECIMAL(10,2),
    status ENUM('pending','success','failed') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
```

---

## 🔮 Future Improvements

- Row-level locking / atomic balance updates to prevent race conditions on concurrent recharges
- Refresh token support
- Email verification on signup
- Deploy backend (Render/Railway) + frontend (Vercel/Netlify) for a live demo link
- Mobile app (Flutter) consuming the same REST API

---

## 📄 License

This project was built for academic/portfolio purposes.

> **Note:** This project uses Razorpay's **test mode** — no real payments are processed.
